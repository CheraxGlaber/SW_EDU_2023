1.0.2 / 2018-01-21
==================

  * Fix encoding `%` as last character

1.0.1 / 2016-06-09
==================

  * Fix encoding unpaired surrogates at start/end of string

1.0.0 / 2016-06-08
==================

  * Initial release
